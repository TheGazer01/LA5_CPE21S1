from ui.pos import POSApp

BUSINESS_NAME = "Endfield's Cafe"
ADDRESS = "Quezon City Branch"
CASHIER = "Cashier 01"
BLACK = "#000000"

if __name__ == "__main__":
    POSApp(BUSINESS_NAME, ADDRESS, CASHIER, BLACK).run()
