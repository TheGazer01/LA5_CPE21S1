import tkinter as tk
from tkinter import messagebox, filedialog
import ttkbootstrap as ttk

from restaurant import Menu, Order, Receipt
from ui.payment_dialog import PaymentDialog
from ui.receipt_window import ReceiptWindow
from utils.formatting import php
from utils.report import export_csv, show_chart
from utils.console import log_payment, show_history


class POSApp:
    def __init__(self, business_name, address, cashier, color="#000000", menu=None):
        self.business_name = business_name
        self.address = address
        self.cashier = cashier
        self.color = color

        self.menu = menu or Menu()
        self.order = Order()
        self.history = []          # (payment class, amount, result) for Chart and Export
        self.receipt_count = 0
        self.sales_total = 0.0
        self.selected_item = None
        self.item_buttons = {}

        self.window = ttk.Window(themename="cosmo")
        self.window.title(f"{self.business_name} - Point-of-Sale System")
        self.window.geometry("1040x680")
        self.window.minsize(980, 640)
        self.window.configure(background=self.color)
        self.window.protocol("WM_DELETE_WINDOW", self.exit_app)

        self.qty_var = tk.StringVar(value="1")
        self.total_var = tk.StringVar()
        self.order_total_var = tk.StringVar()
        self.selected_var = tk.StringVar(value="Selected: none")
        self.count_var = tk.StringVar()
        self.sales_var = tk.StringVar()

        self._build_styles()
        self._build_menubar()
        self._build_header()
        self._build_body()
        self.refresh_order()
        self.refresh_sales()

    def run(self):
        self.window.mainloop()

    # ------------------------------------------------------------ layout
    def _build_styles(self):
        style = ttk.Style()
        style.configure("Blue.TFrame", background=self.color)
        style.configure("Blue.TLabel", background=self.color, foreground="white")
        style.configure("Card.TFrame", background="white")
        style.configure("Card.TLabel", background="white", foreground="#1f2937")
        style.configure("Card.TLabelframe", background="white", bordercolor="#c9ced6")
        style.configure("Card.TLabelframe.Label", background="white",
                        foreground="#1f2937", font=("Segoe UI", 9, "bold"))
        style.configure("Treeview", rowheight=28)

    def _build_menubar(self):
        menubar = tk.Menu(self.window)
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="New Transaction", command=self.new_transaction_button)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.exit_app)
        menubar.add_cascade(label="File", menu=file_menu)

        reports_menu = tk.Menu(menubar, tearoff=0)
        reports_menu.add_command(label="Payments Chart",
                                 command=lambda: show_chart(self.window, self.history))
        reports_menu.add_command(label="Export Sales to CSV", command=self.export)
        menubar.add_cascade(label="Reports", menu=reports_menu)
        self.window.configure(menu=menubar)

    def _build_header(self):
        header = ttk.Frame(self.window, style="Blue.TFrame")
        header.pack(side="top", pady=(14, 10))
        ttk.Label(header, text=self.business_name.upper(), style="Blue.TLabel",
                  font=("Segoe UI", 22, "bold")).pack()
        ttk.Label(header, text="Point-of-Sale System", style="Blue.TLabel",
                  font=("Segoe UI", 11)).pack()
        ttk.Label(header, text=f"{self.address}   |   Cashier: {self.cashier}",
                  style="Blue.TLabel", font=("Segoe UI", 10)).pack()

    def _build_body(self):
        body = ttk.Frame(self.window, style="Card.TFrame", padding=12)
        body.pack(side="top", fill="both", expand=True, padx=20, pady=(0, 20))
        body.columnconfigure(0, weight=3, uniform="area")
        body.columnconfigure(1, weight=4, uniform="area")
        body.columnconfigure(2, weight=2, uniform="area")
        body.rowconfigure(0, weight=1)

        self._build_menu_area(body)
        self._build_order_area(body)
        self._build_transaction_area(body)

    def _build_menu_area(self, parent):
        area = ttk.Labelframe(parent, text="MENU", style="Card.TLabelframe", padding=10)
        area.grid(row=0, column=0, sticky="nsew", padx=(0, 8))

        notebook = ttk.Notebook(area)
        notebook.pack(fill="both", expand=True)
        for category in self.menu.categories():
            tab = ttk.Frame(notebook, padding=8)
            notebook.add(tab, text=category)
            for item in self.menu.items_in(category):
                button = ttk.Button(tab, text=f"{item.name}   {php(item.price)}",
                                    bootstyle="primary-outline",
                                    command=lambda i=item: self.select_item(i))
                button.pack(fill="x", pady=3, ipady=3)
                self.item_buttons[item.name] = button

        ttk.Label(area, textvariable=self.selected_var, style="Card.TLabel",
                  wraplength=260, justify="left").pack(anchor="w", pady=(10, 4))

        quantity_row = ttk.Frame(area, style="Card.TFrame")
        quantity_row.pack(fill="x")
        ttk.Label(quantity_row, text="Quantity:", style="Card.TLabel").pack(side="left")
        spinbox = ttk.Spinbox(quantity_row, from_=1, to=99, width=5, textvariable=self.qty_var)
        spinbox.pack(side="left", padx=8)
        spinbox.bind("<Return>", lambda event: self.add_to_order())

        ttk.Button(area, text="ADD TO ORDER", bootstyle="primary",
                   command=self.add_to_order).pack(fill="x", pady=(8, 0), ipady=3)

    def _build_order_area(self, parent):
        area = ttk.Labelframe(parent, text="CURRENT ORDER", style="Card.TLabelframe", padding=10)
        area.grid(row=0, column=1, sticky="nsew", padx=4)

        table = ttk.Frame(area, style="Card.TFrame")
        table.pack(fill="both", expand=True)
        columns = ("item", "qty", "price", "subtotal")
        self.order_tree = ttk.Treeview(table, columns=columns, show="headings",
                                       selectmode="browse", height=10)
        for column, heading, width, anchor in [
            ("item", "Item", 140, "w"),
            ("qty", "Qty", 40, "center"),
            ("price", "Price", 70, "e"),
            ("subtotal", "Subtotal", 80, "e"),
        ]:
            self.order_tree.heading(column, text=heading)
            self.order_tree.column(column, width=width, anchor=anchor,
                                   stretch=(column == "item"))
        scroll = ttk.Scrollbar(table, orient="vertical", command=self.order_tree.yview)
        self.order_tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.order_tree.pack(side="left", fill="both", expand=True)

        buttons = ttk.Frame(area, style="Card.TFrame")
        buttons.pack(fill="x", pady=(10, 0))
        ttk.Button(buttons, text="Remove Selected", bootstyle="danger-outline",
                   command=self.remove_selected).pack(side="left", expand=True, fill="x", padx=(0, 4))
        ttk.Button(buttons, text="Clear Order", bootstyle="secondary-outline",
                   command=self.clear_order).pack(side="left", expand=True, fill="x", padx=(4, 0))

        ttk.Label(area, textvariable=self.order_total_var, style="Card.TLabel",
                  font=("Segoe UI", 14, "bold")).pack(anchor="e", pady=(10, 0))

    def _build_transaction_area(self, parent):
        area = ttk.Labelframe(parent, text="TRANSACTION", style="Card.TLabelframe", padding=10)
        area.grid(row=0, column=2, sticky="nsew", padx=(8, 0))

        ttk.Label(area, text="Total:", style="Card.TLabel").pack(anchor="w")
        ttk.Label(area, textvariable=self.total_var, style="Card.TLabel",
                  font=("Segoe UI", 18, "bold")).pack(anchor="w", pady=(0, 14))

        ttk.Button(area, text="PROCEED TO PAYMENT", bootstyle="success",
                   command=self.proceed_to_payment).pack(fill="x", pady=4, ipady=6)
        ttk.Button(area, text="NEW TRANSACTION", bootstyle="warning-outline",
                   command=self.new_transaction_button).pack(fill="x", pady=4, ipady=3)

        ttk.Separator(area).pack(fill="x", pady=12)
        ttk.Label(area, text="Sales this session", style="Card.TLabel").pack(anchor="w")
        ttk.Label(area, textvariable=self.count_var, style="Card.TLabel").pack(anchor="w")
        ttk.Label(area, textvariable=self.sales_var, style="Card.TLabel",
                  font=("Segoe UI", 11, "bold")).pack(anchor="w")

        ttk.Separator(area).pack(fill="x", pady=12)
        ttk.Button(area, text="Payments Chart", bootstyle="secondary-outline",
                   command=lambda: show_chart(self.window, self.history)).pack(fill="x", pady=3)
        ttk.Button(area, text="Export CSV", bootstyle="secondary-outline",
                   command=self.export).pack(fill="x", pady=3)
        ttk.Button(area, text="Exit", bootstyle="danger-outline",
                   command=self.exit_app).pack(side="bottom", fill="x", pady=3)

    # ------------------------------------------------------------ order actions
    def select_item(self, item):
        self.selected_item = item
        self.selected_var.set(f"Selected: {item.name} ({php(item.price)})")
        for name, button in self.item_buttons.items():
            button.configure(bootstyle="primary" if name == item.name else "primary-outline")

    def add_to_order(self):
        if self.selected_item is None:
            messagebox.showerror("No Item Selected", "Please select a menu item first.")
            return
        try:
            quantity = int(self.qty_var.get())
        except ValueError:
            messagebox.showerror("Invalid Quantity",
                                 "Please enter a whole number for the quantity.")
            return
        try:
            self.order.add_item(self.selected_item, quantity)
        except ValueError as error:
            messagebox.showerror("Invalid Quantity", str(error))
            return
        self.qty_var.set("1")
        self.refresh_order()

    def remove_selected(self):
        selection = self.order_tree.selection()
        if not selection:
            messagebox.showerror("Nothing Selected",
                                 "Please select an item in the order to remove.")
            return
        for name in selection:
            self.order.remove_item(name)
        self.refresh_order()

    def clear_order(self):
        if self.order.is_empty():
            return
        if messagebox.askyesno("Clear Order", "Remove all items from the current order?"):
            self.order.clear()
            self.refresh_order()

    def refresh_order(self):
        self.order_tree.delete(*self.order_tree.get_children())
        for line in self.order.lines:
            self.order_tree.insert("", "end", iid=line.item.name, values=(
                line.item.name, line.quantity, php(line.item.price), php(line.subtotal)))
        total = php(self.order.total())
        self.total_var.set(total)
        self.order_total_var.set(f"TOTAL: {total}")

    def refresh_sales(self):
        self.count_var.set(f"Transactions: {self.receipt_count}")
        self.sales_var.set(f"Sales: {php(self.sales_total)}")

    # ------------------------------------------------------------ payment
    def proceed_to_payment(self):
        if self.order.is_empty():
            messagebox.showerror("No Order", "Please add at least one item to the order.")
            return
        PaymentDialog(self.window, self.order.total(), self.process_payment)

    def process_payment(self, payment, spec, info):
        """The one payment function for every method (polymorphism).

        payment can be any Payment subclass; pay() runs that class's version.
        """
        amount = self.order.total()
        try:
            result = payment.pay(amount)
        except Exception as error:
            messagebox.showerror("Payment Failed", str(error))
            return False

        self.receipt_count += 1
        self.sales_total += amount
        self.history.append((payment.__class__.__name__, amount, result))
        log_payment(self.receipt_count, result)

        receipt = Receipt(
            self.business_name, self.address, self.cashier, self.receipt_count,
            self.order, amount, spec.receipt_label,
            details=info.details, received=info.received, change=info.change,
        )
        self.refresh_sales()
        ReceiptWindow(self.window, receipt, result, self.reset_order)
        return True

    # ------------------------------------------------------------ transaction
    def reset_order(self):
        self.order.clear()
        self.qty_var.set("1")
        self.refresh_order()

    def new_transaction_button(self):
        if not self.order.is_empty() and not messagebox.askyesno(
                "New Transaction", "Clear the current order and start a new transaction?"):
            return
        self.reset_order()

    def export(self):
        if not self.history:
            messagebox.showinfo("Nothing to Export", "Complete a payment first.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV file", "*.csv")]
        )
        if path:
            export_csv(self.history, path)
            messagebox.showinfo("Exported", f"Saved to {path}")

    def exit_app(self):
        if not self.order.is_empty() and not messagebox.askyesno(
                "Exit", "There is an unpaid order. Exit anyway?"):
            return
        show_history(self.history)
        self.window.destroy()
