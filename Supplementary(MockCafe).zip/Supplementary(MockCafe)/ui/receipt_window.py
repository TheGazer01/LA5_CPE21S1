import tkinter as tk
from tkinter import messagebox, filedialog
import ttkbootstrap as ttk
from PIL import ImageTk

from utils.qr import make_qr
from utils.receipt import make_pos_receipt_pdf


class ReceiptWindow(tk.Toplevel):
    """Shows the receipt text and QR code. Closing it starts a new transaction."""

    def __init__(self, parent, receipt, result, on_new_transaction):
        super().__init__(parent)
        self.title(f"Receipt {receipt.number_text}")
        self.resizable(False, False)
        self.transient(parent)

        self.receipt = receipt
        self.on_new_transaction = on_new_transaction

        body = ttk.Frame(self, padding=15)
        body.pack(fill="both", expand=True)

        ttk.Label(body, text="PAYMENT SUCCESSFUL", font=("Segoe UI", 14, "bold"),
                  bootstyle="success").pack()
        ttk.Label(body, text=result).pack(pady=(0, 10))

        middle = ttk.Frame(body)
        middle.pack()

        lines = receipt.lines()
        text = tk.Text(middle, width=max(len(line) for line in lines) + 2,
                       height=len(lines) + 1, font=("Consolas", 10), relief="solid",
                       borderwidth=1, wrap="none")
        text.insert("1.0", "\n".join(lines))
        text.configure(state="disabled")
        text.pack(side="left")

        side = ttk.Frame(middle)
        side.pack(side="left", padx=(15, 0), anchor="n")
        self.qr_image = ImageTk.PhotoImage(make_qr(receipt.qr_payload, 150))
        ttk.Label(side, image=self.qr_image).pack()
        ttk.Label(side, text="Scan for your receipt").pack(pady=(4, 14))
        ttk.Button(side, text="Save PDF Receipt", bootstyle="secondary-outline",
                   command=self.save_pdf).pack(fill="x", pady=3)
        ttk.Button(side, text="NEW TRANSACTION", bootstyle="success",
                   command=self.new_transaction).pack(fill="x", pady=3)

        self.protocol("WM_DELETE_WINDOW", self.new_transaction)

        self.update_idletasks()
        x = parent.winfo_rootx() + (parent.winfo_width() - self.winfo_reqwidth()) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - self.winfo_reqheight()) // 2
        self.geometry(f"+{max(x, 0)}+{max(y, 0)}")
        self.wait_visibility()
        self.grab_set()

    def save_pdf(self):
        path = filedialog.asksaveasfilename(
            parent=self,
            defaultextension=".pdf",
            initialfile=f"receipt_{self.receipt.number_text}.pdf",
            filetypes=[("PDF file", "*.pdf")]
        )
        if not path:
            return
        try:
            make_pos_receipt_pdf(self.receipt.lines(peso=False), self.receipt.qr_payload, path)
        except OSError as error:
            messagebox.showerror("Could Not Save", str(error), parent=self)
            return
        messagebox.showinfo("Saved", f"Receipt saved to {path}", parent=self)

    def new_transaction(self):
        self.grab_release()
        self.destroy()
        self.on_new_transaction()
