import tkinter as tk
from tkinter import messagebox
import ttkbootstrap as ttk
from PIL import ImageTk

from restaurant.payment_methods import METHODS
from utils.icons import make_icon
from utils.formatting import php


class PaymentDialog(tk.Toplevel):
    """Asks the cashier for a payment method and its details.

    The dialog builds a payment object from the chosen method and hands it to
    on_confirm(payment, spec, info). Every method is handled the same way.
    """

    def __init__(self, parent, total, on_confirm):
        super().__init__(parent)
        self.title("Payment")
        self.resizable(False, False)
        self.transient(parent)

        self.total = total
        self.on_confirm = on_confirm
        self.spec = None
        self.icons = []
        self.buttons = {}

        self._build()
        self.bind("<Return>", lambda event: self.confirm())
        self.bind("<Escape>", lambda event: self.destroy())

        self.update_idletasks()
        x = parent.winfo_rootx() + (parent.winfo_width() - self.winfo_reqwidth()) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - self.winfo_reqheight()) // 2
        self.geometry(f"+{max(x, 0)}+{max(y, 0)}")
        self.wait_visibility()
        self.grab_set()

    def _build(self):
        body = ttk.Frame(self, padding=20)
        body.pack(fill="both", expand=True)

        ttk.Label(body, text="Total Amount", font=("Segoe UI", 10)).pack()
        ttk.Label(body, text=php(self.total), font=("Segoe UI", 24, "bold"),
                  bootstyle="success").pack(pady=(0, 12))

        ttk.Label(body, text="Select a payment method:").pack(anchor="w")
        grid = ttk.Frame(body)
        grid.pack(fill="x", pady=(6, 12))
        for column in range(3):
            grid.columnconfigure(column, weight=1, uniform="method")
        for index, spec in enumerate(METHODS):
            icon = ImageTk.PhotoImage(make_icon(spec.name))
            self.icons.append(icon)
            button = ttk.Button(grid, text=spec.name, image=icon, compound="left",
                                bootstyle="primary-outline",
                                command=lambda s=spec: self.select_method(s))
            button.grid(row=index // 3, column=index % 3, sticky="ew",
                        padx=3, pady=3, ipady=2)
            self.buttons[spec.name] = button

        self.field_label = ttk.Label(body, text="Payment details:")
        self.field_label.pack(anchor="w")
        self.entry = ttk.Entry(body, width=34, state="disabled")
        self.entry.pack(fill="x", pady=(4, 2))
        self.hint_label = ttk.Label(body, text="Choose a payment method first.",
                                    bootstyle="secondary")
        self.hint_label.pack(anchor="w")

        actions = ttk.Frame(body)
        actions.pack(fill="x", pady=(18, 0))
        ttk.Button(actions, text="CONFIRM PAYMENT", bootstyle="success",
                   command=self.confirm).pack(side="left", expand=True, fill="x", padx=(0, 6))
        ttk.Button(actions, text="Cancel", bootstyle="secondary-outline",
                   command=self.destroy).pack(side="left")

    def select_method(self, spec):
        self.spec = spec
        for name, button in self.buttons.items():
            button.configure(bootstyle="primary" if name == spec.name else "primary-outline")
        self.field_label.configure(text=spec.field_label)
        self.hint_label.configure(text=spec.hint)
        self.entry.configure(state="normal")
        self.entry.delete(0, "end")
        self.entry.focus_set()

    def confirm(self):
        if self.spec is None:
            messagebox.showerror("No Payment Method",
                                 "Please select a payment method.", parent=self)
            return
        try:
            info = self.spec.validate(self.entry.get(), self.total)
        except ValueError as error:
            message = str(error)
            title = "Insufficient Payment" if message.startswith("Insufficient") else "Invalid Input"
            messagebox.showerror(title, message, parent=self)
            return
        payment = self.spec.payment_class()
        if self.on_confirm(payment, self.spec, info):
            self.destroy()
