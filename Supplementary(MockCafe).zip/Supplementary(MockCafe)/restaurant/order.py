from dataclasses import dataclass

from utils.formatting import php

MAX_QUANTITY = 99


@dataclass
class OrderLine:
    item: object
    quantity: int

    @property
    def subtotal(self):
        return round(self.item.price * self.quantity, 2)


class Order:
    """The cashier's current order: items, quantities, subtotals and total."""

    def __init__(self):
        self._lines = {}

    def add_item(self, item, quantity=1):
        if isinstance(quantity, bool) or not isinstance(quantity, int) or quantity < 1:
            raise ValueError("Please enter a whole number of at least 1 for the quantity.")
        current = self._lines[item.name].quantity if item.name in self._lines else 0
        if current + quantity > MAX_QUANTITY:
            raise ValueError(f"The quantity for one item cannot be more than {MAX_QUANTITY}.")
        if item.name in self._lines:
            self._lines[item.name].quantity += quantity
        else:
            self._lines[item.name] = OrderLine(item, quantity)

    def remove_item(self, name):
        if name not in self._lines:
            raise KeyError(name)
        del self._lines[name]

    def clear(self):
        self._lines.clear()

    @property
    def lines(self):
        return list(self._lines.values())

    def is_empty(self):
        return not self._lines

    def total(self):
        return round(sum(line.subtotal for line in self._lines.values()), 2)

    def display(self):
        if self.is_empty():
            return "No items in the order."
        rows = []
        for line in self.lines:
            rows.append(line.item.name)
            rows.append(f"{php(line.item.price)} × {line.quantity} = {php(line.subtotal)}")
        rows.append("-" * 25)
        rows.append(f"TOTAL = {php(self.total())}")
        return "\n".join(rows)
