from dataclasses import dataclass


@dataclass(frozen=True)
class MenuItem:
    name: str
    category: str
    price: float


class Menu:
    """Stores the restaurant's menu items (name, category, price)."""

    def __init__(self, items=None):
        self._items = list(items) if items is not None else self.default_items()

    @staticmethod
    def default_items():
        # Mock menu for Endfield's Cafe. All names and prices are made up.
        return [
            MenuItem("Garlic Chicken Rice", "Meals", 129.00),
            MenuItem("Beef Tapa Meal", "Meals", 149.00),
            MenuItem("Pork Sisig Bowl", "Meals", 139.00),
            MenuItem("Cafe Spaghetti", "Meals", 99.00),
            MenuItem("Iced Coffee", "Drinks", 75.00),
            MenuItem("Hot Latte", "Drinks", 85.00),
            MenuItem("Milk Tea", "Drinks", 65.00),
            MenuItem("Calamansi Juice", "Drinks", 45.00),
            MenuItem("Bottled Water", "Drinks", 25.00),
            MenuItem("Extra Rice", "Add-ons", 20.00),
            MenuItem("French Fries", "Add-ons", 55.00),
            MenuItem("Fried Egg", "Add-ons", 25.00),
            MenuItem("Cheese Sauce", "Add-ons", 15.00),
        ]

    def all_items(self):
        return list(self._items)

    def categories(self):
        seen = []
        for item in self._items:
            if item.category not in seen:
                seen.append(item.category)
        return seen

    def items_in(self, category):
        return [item for item in self._items if item.category == category]

    def find(self, name):
        for item in self._items:
            if item.name == name:
                return item
        return None
