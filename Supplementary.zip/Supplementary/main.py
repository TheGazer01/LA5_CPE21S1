import tkinter as tk
from tkinter import messagebox, filedialog
import ttkbootstrap as ttk
from PIL import ImageTk

from payments import (
    CashPayment,
    EWalletPayment,
    CreditCardPayment,
    DebitCardPayment,
    BankTransferPayment,
)
from utils.icons import make_icon
from utils.qr import make_qr
from utils.report import export_csv, show_chart
from utils.console import log_payment, show_history

BUSINESS_NAME = "My Business"
BLUE = "#1a56db"

history = []

window = ttk.Window(themename="cosmo")
window.title(BUSINESS_NAME)
window.geometry("420x630")
window.configure(background=BLUE)

style = ttk.Style()
style.configure("Blue.TFrame", background=BLUE)
style.configure("Blue.TLabel", background=BLUE, foreground="white")
style.configure("Card.TFrame", background="white")
style.configure("Card.TLabel", background="white", foreground="#1f2937")

header = ttk.Frame(window, style="Blue.TFrame")
header.pack(pady=(30, 20))
ttk.Label(header, text=BUSINESS_NAME.upper(), style="Blue.TLabel",
          font=("Segoe UI", 22, "bold")).pack()
ttk.Label(header, text="Payment System", style="Blue.TLabel",
          font=("Segoe UI", 10)).pack()

card = ttk.Frame(window, style="Card.TFrame", padding=25)
card.pack(fill="x", padx=30)

ttk.Label(card, text="Amount (PHP)", style="Card.TLabel").pack(anchor="w")
amount_entry = ttk.Entry(card, font=("Segoe UI", 16), justify="center")
amount_entry.pack(fill="x", pady=(5, 15))

ttk.Label(card, text="Choose a payment method", style="Card.TLabel").pack(anchor="w")

def show_receipt(result):
    receipt = tk.Toplevel(window)
    receipt.title("Payment Successful")
    receipt.geometry("340x470")
    receipt.configure(background="white")
    ttk.Label(receipt, text="Payment Successful", style="Card.TLabel",
              font=("Segoe UI", 16, "bold")).pack(pady=(20, 5))
    ttk.Label(receipt, text=result, style="Card.TLabel",
              wraplength=280, justify="center").pack(pady=5)
    qr_image = ImageTk.PhotoImage(make_qr(f"{BUSINESS_NAME}\n{result}"))
    qr_label = ttk.Label(receipt, image=qr_image, style="Card.TLabel")
    qr_label.image = qr_image
    qr_label.pack(pady=10)
    ttk.Label(receipt, text="Scan for your receipt", style="Card.TLabel").pack()
    ttk.Button(receipt, text="Close", bootstyle="primary", width=20,
               command=receipt.destroy).pack(pady=15)

def process_payment(payment):
    try:
        amount = float(amount_entry.get())
        if amount <= 0:
            messagebox.showerror(
                "Invalid Amount",
                "Please enter an amount greater than zero."
            )
            return
        result = payment.pay(amount)
        history.append((payment.__class__.__name__, amount, result))
        log_payment(len(history), result)
        show_receipt(result)
    except ValueError:
        messagebox.showerror(
            "Invalid Input",
            "Please enter a valid amount."
        )

def export():
    if not history:
        messagebox.showinfo("Nothing to Export", "Make a payment first.")
        return
    path = filedialog.asksaveasfilename(
        defaultextension=".csv",
        filetypes=[("CSV file", "*.csv")]
    )
    if path:
        export_csv(history, path)
        messagebox.showinfo("Exported", f"Saved to {path}")

def exit_app():
    show_history(history)
    window.destroy()

payment_methods = [
    ("Cash", CashPayment),
    ("E-Wallet", EWalletPayment),
    ("Credit Card", CreditCardPayment),
    ("Debit Card", DebitCardPayment),
    ("Bank Transfer", BankTransferPayment),
]

icons = []
for name, payment_class in payment_methods:
    icon = ImageTk.PhotoImage(make_icon(name))
    icons.append(icon)
    ttk.Button(
        card,
        text=name,
        image=icon,
        compound="left",
        bootstyle="primary-outline",
        command=lambda pc=payment_class: process_payment(pc())
    ).pack(fill="x", pady=4, ipady=4)

footer = ttk.Frame(window, style="Blue.TFrame")
footer.pack(fill="x", padx=30, pady=20)
for text, command in [
    ("Chart", lambda: show_chart(window, history)),
    ("Export", export),
    ("Exit", exit_app),
]:
    ttk.Button(footer, text=text, bootstyle="light",
               command=command).pack(side="left", expand=True, fill="x", padx=4)

window.mainloop()